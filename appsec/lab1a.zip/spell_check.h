#ifndef SPELL_CHECK
#define SPELL_CHECK

char *spell_check(char *text);
int check_word(char *word, int dictfd);

#endif